# Changelog

All notable changes to Rune (Self-Improving AI Memory System) will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-02-25

### 🔒 Complete Security & Package Overhaul (ClawHub Review Response)

#### Added
- **Complete self-contained package** - All source code, dependencies included
- **Automatic backup system** - Backs up HEARTBEAT.md and memory.db before changes
- **Installation verification modes** - `--dry-run`, `--verify`, `--force` options
- **Enhanced security documentation** - Complete SECURITY.md with audit info
- **Local-first defaults** - Ollama default, cloud APIs explicitly opt-in
- **Minimal dependency set** - Only 2 required deps (sqlite3, commander)

#### Changed
- **Unified naming**: All `brokkr-mem` references → `rune` throughout
- **CLI command**: Now `rune` instead of `brokkr-mem` for consistency
- **Package structure**: Self-contained with no external git clone required
- **Installation process**: More secure with backups and verification
- **Default behavior**: Local models preferred, cloud optional

#### Fixed  
- **Package completeness**: No more missing package.json or source files
- **Installation reliability**: Self-contained package eliminates external dependencies
- **Security transparency**: All dependencies visible and auditable
- **Naming consistency**: Skill name and CLI command now aligned

#### Security
- **CVE-2026-0001**: Remains fixed from v1.0.2 (shell injection)
- **Package integrity**: Complete source code included for security review
- **Dependency audit**: Clean audit with minimal, vetted dependencies
- **Installation safety**: Automatic backups prevent data loss

#### Developer Experience
- **Better error handling**: Clear messages for common issues
- **Verification tools**: Easy package integrity checking
- **Documentation**: Comprehensive security and installation guides
- **Testing**: Dry-run mode for safe installation preview

## [1.0.3] - 2026-02-25

### 📋 Documentation Fixes (ClawHub Security Review Response)

#### Fixed
- **Repository URL inconsistencies** in SKILL.md (placeholder URLs updated)
- **Naming clarification** - Added section explaining Rune (skill) vs brokkr-mem (CLI)
- **Installation disclosure** - Clear documentation of installation side effects

#### Added
- **Installation warning section** with detailed disclosure of what installation does
- **Enhanced security documentation** including NPM dependency considerations  
- **Privacy recommendations** for high-security environments
- **Better explanation** of the relationship between skill name and CLI name

#### Changed
- Updated placeholder repository URLs from `github.com/your-org/brokkr-mem` to `github.com/TheBobLoblaw/rune`
- Enhanced installation section with security considerations
- Improved security & privacy documentation based on ClawHub review feedback

#### Security
- **No functional changes** - this is purely documentation improvement
- All security fixes from v1.0.2 (CVE-2026-0001) remain intact
- Added better disclosure of npm installation security considerations

## [1.0.2] - 2026-02-24

### 🔒 SECURITY

**CRITICAL SECURITY FIX** - CVE-2026-0001

#### Fixed
- **Shell injection vulnerability** in session hooks that allowed remote code execution
- Direct use of unsanitized `$MESSAGE` variable in `brokkr-mem` commands
- Potential for arbitrary command execution through crafted user input

#### Added
- **Secure session handler** (`rune-session-handler.sh`) with comprehensive input sanitization
- Input length limits and dangerous character filtering
- Safe command execution patterns throughout
- Security documentation and usage guidance

#### Changed
- Session hooks now use secure wrapper instead of direct command execution
- `sessionStart` and `sessionEnd` hooks route through sanitization layer
- Updated SKILL.md with security best practices and warnings

#### Security Details
```bash
# BEFORE (Vulnerable):
"sessionStart": {"commands": ["brokkr-mem recall \"$MESSAGE\" --limit 10"]}

# AFTER (Secure):  
"sessionStart": {"commands": ["./rune-session-handler.sh start"]}
```

**Attack Vector**: Malicious input like `test"; rm -rf /; echo "hacked` could execute arbitrary commands
**Impact**: Complete system compromise possible
**Fix**: All user input now sanitized before shell execution

---

## [1.0.1] - 2026-02-24

### Added
- Enhanced extraction engine with multi-format support
- Session-aware context injection
- Improved fact consolidation algorithms
- Autonomous task detection and recommendations

### Changed
- Optimized memory retrieval performance
- Enhanced CLI usability and error handling
- Improved fact scoring accuracy

### Fixed
- Memory consolidation edge cases
- CLI argument parsing improvements

---

## [1.0.0] - 2026-02-23

### Added
- **Initial Release** - Self-Improving AI Memory System
- SQLite-based persistent memory storage
- Local-first design with Ollama integration
- Intelligent fact extraction and scoring
- Session-aware context management
- CLI tools: `brokkr-mem` and `rune`
- OpenClaw skill integration
- Heartbeat maintenance automation
- Memory categories: person, project, tool, lesson, decision, preference
- Local and cloud LLM support (Ollama, OpenAI, Anthropic)

### Features
- **Intelligent Storage**: Facts auto-categorized and scored for relevance
- **Smart Retrieval**: Semantic and keyword search with LLM ranking
- **Self-Improvement**: System learns from usage patterns and adapts
- **Privacy-First**: Works completely offline with local models
- **Agent Integration**: Designed for AI orchestration workflows

### Security
- No credential storage in memory database
- Local-first processing for privacy
- Optional cloud API integration
- Transparent data handling